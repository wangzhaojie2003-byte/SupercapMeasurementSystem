/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dac.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "dac.h"
#include "usart.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
extern UART_HandleTypeDef huart2;
extern DAC_HandleTypeDef hdac;
extern ADC_HandleTypeDef  hadc1;
extern ADC_HandleTypeDef  hadc2;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SAMPLE_PERIOD_MS  1
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
static char rx_buf[64];   // UART receive buffer
static char cmd_buf[64];  // Command buffer
static int  cmd_len = 0;  // Command length
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static inline uint32_t volt_to_dac(float v);

void send_str(const char* s){
  HAL_UART_Transmit(&huart2, (uint8_t*)s, strlen(s), HAL_MAX_DELAY);
}

void handle_cmd(const char* s){
  float v;
  if(strncmp(s,"SET",3)==0){
    if(sscanf(s+3,"%f",&v)==1){
      HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, volt_to_dac(v));
      send_str("OK\r\n");
    } else {
      send_str("ERR PARSE\r\n");
    }
  } else if(strncmp(s,"GET",3)==0){
    uint32_t code = HAL_DAC_GetValue(&hdac, DAC_CHANNEL_1);
    float vo = (code/4095.0f)*3.3f;
    char buf[32];
    snprintf(buf,sizeof(buf),"V=%.3f\r\n",vo);
    send_str(buf);
  } else {
    send_str("ERR CMD\r\n");
  }
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// Scaler
#define ADC_REF_V        3.3f
#define ADC_MAX_CODE     4095.0f

// ADC1 reading to Current：I[A] = Vadc * CURRENT_A_PER_V
// e.g. For 0.1V/A（10A -> 1.0V），then CURRENT_A_PER_V = 1 / 0.1 = 10.0f
#ifndef CURRENT_A_PER_V
#define CURRENT_A_PER_V  1.0f
#endif

// ADC2 reading to cap voltage：Vreal = Vadc * VOLTAGE_RATIO
#ifndef VOLTAGE_RATIO
#define VOLTAGE_RATIO    1.0f
#endif

static inline float adc_code_to_volt(uint16_t code){
  return (code / ADC_MAX_CODE) * ADC_REF_V;
}

static inline uint16_t adc_sample_blocking(ADC_HandleTypeDef* hadc){
  HAL_ADC_Start(hadc);
  HAL_StatusTypeDef st = HAL_ADC_PollForConversion(hadc, 10);
  uint16_t code = 0;
  if(st == HAL_OK){
    code = (uint16_t)HAL_ADC_GetValue(hadc);
  }
  HAL_ADC_Stop(hadc);
  return code;
}

static inline uint32_t volt_to_dac(float v){
  if(v < 0.0f) v = 0.0f;
  if(v > 3.3f) v = 3.3f;
  return (uint32_t)((v/3.3f)*4095.0f + 0.5f);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  MX_ADC1_Init();
  MX_ADC2_Init();

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_DAC_Init();
  /* USER CODE BEGIN 2 */
  HAL_DAC_Start(&hdac, DAC_CHANNEL_1);

  send_str("READY\r\n");
  HAL_Delay(10);

  HAL_ADC_Start(&hadc1);
  HAL_ADC_Start(&hadc2);

  // Start UART receive interrupt (single byte)
  HAL_UART_Receive_IT(&huart2,(uint8_t*)rx_buf,1);

  uint32_t last_print_ms = HAL_GetTick();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if(HAL_GetTick() - last_print_ms >= SAMPLE_PERIOD_MS){
	    last_print_ms += SAMPLE_PERIOD_MS  ;

	    // read ADC1 and ADC2
	    uint16_t code_i = adc_sample_blocking(&hadc1);
	    uint16_t code_v = adc_sample_blocking(&hadc2);

	    float vadc_i = adc_code_to_volt(code_i);
	    float vadc_v = adc_code_to_volt(code_v);

	    float i_amp  = vadc_i * CURRENT_A_PER_V;   // A
	    float v_volt = vadc_v * VOLTAGE_RATIO;     // V

	    char line[64];

	    int32_t mA = (int32_t)(i_amp*1000.0f + (i_amp>=0?0.5f:-0.5f));
	    int32_t mV = (int32_t)(v_volt*1000.0f + (v_volt>=0?0.5f:-0.5f));
	    int n = snprintf(line, sizeof(line), "%ld,%ld\r\n", (long)mA, (long)mV);

//

//	    int n = snprintf(line, sizeof(line), "I=%.3fA V=%.3fV\r\n", i_amp, v_volt);
	    if(n > 0){
	      send_str(line);
	    }

	  }
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {

  HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin); // Toggle LED for debug
  if(huart->Instance == USART2){
    char c = rx_buf[0];
    if(c=='\r' || c=='\n'){
      if(cmd_len>0){
        cmd_buf[cmd_len]=0;
        handle_cmd(cmd_buf);
        cmd_len=0;
      }
    } else {
      if(cmd_len < (int)sizeof(cmd_buf)-1){
        cmd_buf[cmd_len++] = c;
      }
    }
    // Continue receiving next byte
    HAL_UART_Receive_IT(&huart2,(uint8_t*)rx_buf,1);
  }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
